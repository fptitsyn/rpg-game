using Lab12.Domain;
using UnityEngine;
using UnityEngine.UI;

namespace Lab12.Runtime
{
    public sealed class HealthBar : MonoBehaviour
    {
        private IReadOnlyHealth health;
        private Image fill;
        private Text label;
        private Camera viewCamera;
        public void Initialize(IReadOnlyHealth model, Image bar, Text text, Camera camera = null)
        {
            health = model; fill = bar; label = text; viewCamera = camera;
            health.Changed += Refresh;
            Refresh(health.Current, health.Maximum);
        }
        private void Refresh(float current, float maximum)
        {
            fill.fillAmount = current / maximum;
            fill.color = Color.Lerp(new Color(0.9f, 0.2f, 0.2f), new Color(0.25f, 0.85f, 0.45f), current / maximum);
            if (label != null) label.text = $"HP  {Mathf.CeilToInt(current)} / {Mathf.CeilToInt(maximum)}";
        }
        private void LateUpdate()
        {
            if (viewCamera != null) transform.rotation = viewCamera.transform.rotation;
        }
        private void OnDestroy() { if (health != null) health.Changed -= Refresh; }
    }
}

using UnityEngine;

namespace Lab12.Runtime
{
    public sealed class PlayerBrain : MonoBehaviour
    {
        private IPlayerInput input;
        private PlayerMotor motor;
        private ActorCombat combat;
        private Combatant actor;
        private CharacterDefinition definition;
        private OrbitCamera orbit;
        public void Initialize(IPlayerInput controls, PlayerMotor movement, ActorCombat attacks,
            Combatant owner, CharacterDefinition settings, OrbitCamera cameraRig)
        { input = controls; motor = movement; combat = attacks; actor = owner; definition = settings; orbit = cameraRig; }
        private void Update()
        {
            motor.SetVelocity(Vector3.zero);
            if (!actor.IsAlive) return;
            if (input.ReleaseCursorPressed) { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
            if (Cursor.lockState != CursorLockMode.Locked)
            {
                if (input.MeleePressed) { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
                return; // The click that captures the mouse must not also attack.
            }
            orbit.Rotate(input.Look);
            if (combat.IsLocked) return;
            Vector3 direction = Quaternion.Euler(0, orbit.Yaw, 0) * new Vector3(input.Move.x, 0, input.Move.y);
            if (input.MeleePressed || input.MagicPressed)
            {
                transform.rotation = Quaternion.Euler(0, orbit.Yaw, 0);
                combat.TryAttack(input.MagicPressed);
            }
            else if (direction.sqrMagnitude > 0.001f)
            {
                transform.rotation = Quaternion.RotateTowards(transform.rotation,
                    Quaternion.LookRotation(direction), 720 * Time.deltaTime);
                motor.SetVelocity(direction * (input.Sprint ? definition.runSpeed : definition.walkSpeed));
            }
        }
    }
}

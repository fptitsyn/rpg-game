using Lab12.Domain;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Lab12.Runtime
{
    public sealed class GameHud : MonoBehaviour
    {
        private IReadOnlyHealth health;
        private ActorCombat combat;
        private Image cooldown;
        private Text cooldownText;
        private GameObject deathPanel;
        public void Initialize(IReadOnlyHealth model, ActorCombat attacks, Image magicFill, Text magicText, GameObject gameOver)
        {
            health = model; combat = attacks; cooldown = magicFill; cooldownText = magicText; deathPanel = gameOver;
            health.Died += OnDeath;
            deathPanel.SetActive(false);
        }
        private void Update()
        {
            float remaining = combat.MagicRemaining;
            cooldown.fillAmount = remaining / combat.MagicCooldown;
            cooldownText.text = remaining > 0 ? $"MAGIC  {remaining:0.0}s" : "MAGIC  READY";
        }
        private void OnDeath()
        {
            deathPanel.SetActive(true);
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        public void Restart() => SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        private void OnDestroy() { if (health != null) health.Died -= OnDeath; }
    }
}

using UnityEngine;

namespace Lab12.Runtime
{
    public interface ICharacterAnimation
    {
        void SetSpeed(float speed);
        void PlayAction(string state);
        void ResumeLocomotion();
    }

    // The only gameplay class that knows about Animator parameters/state names.
    public sealed class CharacterAnimation : MonoBehaviour, ICharacterAnimation
    {
        private Animator animator;
        private bool legacy;
        private CharacterDefinition definition;
        private bool action;
        private static readonly int Speed = Animator.StringToHash("Speed");

        public void Initialize(Animator target, CharacterDefinition settings)
        {
            animator = target;
            definition = settings;
            legacy = settings.legacyMonsterAnimator;
            animator.applyRootMotion = false;
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        }
        public void SetSpeed(float speed)
        {
            if (legacy)
            {
                if (Has("Walking", AnimatorControllerParameterType.Bool))
                    animator.SetBool("Walking", !action && speed > 0.1f);
            }
            else animator.SetFloat(Speed, action ? 0 : speed, 0.1f, Time.deltaTime);
        }
        public void PlayAction(string state)
        {
            action = true;
            if (!legacy)
            {
                float duration = state == "Hit" ? definition.hitDuration :
                    state == "Magic" ? definition.magicDuration : definition.meleeDuration;
                float rate = 1;
                if (state != "Death")
                    foreach (var clip in animator.runtimeAnimatorController.animationClips)
                        if (clip.name == state) { rate = clip.length / Mathf.Max(0.01f, duration); break; }
                animator.SetFloat("ActionSpeed", rate);
                animator.CrossFadeInFixedTime("Base Layer." + state, 0.06f, 0, 0);
                return;
            }
            string parameter = state == "Hit" ? "TakeDamage" :
                state == "Death" ? "Death" : "Attack";
            if (Has("Walking", AnimatorControllerParameterType.Bool)) animator.SetBool("Walking", false);
            foreach (var p in animator.parameters)
                if (p.type == AnimatorControllerParameterType.Trigger) animator.ResetTrigger(p.nameHash);
            if (Has(parameter, AnimatorControllerParameterType.Trigger)) animator.SetTrigger(parameter);
        }
        public void ResumeLocomotion()
        {
            if (!action) return;
            action = false;
            if (!legacy) animator.CrossFadeInFixedTime("Base Layer.Locomotion", 0.1f, 0, 0);
        }
        private bool Has(string name, AnimatorControllerParameterType type)
        {
            foreach (var p in animator.parameters) if (p.name == name && p.type == type) return true;
            return false;
        }
    }
}

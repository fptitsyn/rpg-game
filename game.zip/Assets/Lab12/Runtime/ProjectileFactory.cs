using Lab12.Domain;
using UnityEngine;

namespace Lab12.Runtime
{
    public sealed class ProjectileFactory
    {
        private readonly Material material;
        public ProjectileFactory(Material material) { this.material = material; }
        public void Spawn(Combatant owner, CharacterDefinition settings, Vector3 direction)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name = "Magic projectile";
            // Swept physics query is authoritative: no trigger race or tunnelling.
            var collider = go.GetComponent<Collider>();
            collider.enabled = false;
            Object.Destroy(collider);
            go.transform.position = owner.AimPoint;
            go.transform.localScale = Vector3.one * 0.28f;
            var renderer = go.GetComponent<Renderer>();
            renderer.sharedMaterial = material;
            var properties = new MaterialPropertyBlock();
            properties.SetColor("_BaseColor", settings.projectileColor);
            renderer.SetPropertyBlock(properties);
            go.AddComponent<MagicProjectile>().Initialize(direction * settings.projectileSpeed,
                settings.projectileLifetime,
                new Damage(settings.magicalDamage, DamageType.Magical, owner.Faction));
        }
    }
}

using System;
using Lab12.Domain;
using UnityEngine;
using UnityEngine.AI;

namespace Lab12.Runtime
{
    public sealed class EnemyBrain : MonoBehaviour
    {
        private Combatant target;
        private Combatant actor;
        private NavMeshAgent agent;
        private ActorCombat combat;
        private ICharacterAnimation animationView;
        private bool ranged;
        private float reach;
        private float nextPath;
        private NavMeshPath candidatePath;

        private void Awake()
        {
            candidatePath = new NavMeshPath();
        }

        public void Initialize(Combatant owner, Combatant player, NavMeshAgent navigation,
            ActorCombat attacks, ICharacterAnimation view, bool isRanged, float meleeReach)
        { actor = owner; target = player; agent = navigation; combat = attacks; animationView = view; ranged = isRanged; reach = meleeReach; }
        private void Update()
        {
            if (!agent || !agent.enabled || !agent.isOnNavMesh) return;
            if (!actor.IsAlive || !target || !target.IsAlive || combat.IsLocked)
            { Stop(); animationView.SetSpeed(0); return; }
            Vector3 toTarget = target.transform.position - transform.position;
            toTarget.y = 0;
            float distance = toTarget.magnitude;
            bool clearShot = CombatPhysics.ClearLine(actor.AimPoint, target.AimPoint);
            var intent = EnemyDecision.Evaluate(distance, target.IsAlive, ranged, clearShot, 10, reach);
            switch (intent)
            {
                case EnemyIntent.Idle: Stop(); break;
                case EnemyIntent.Approach:
                    Navigate(target.transform.position, !clearShot ? 0.3f : ranged ? 6.5f : reach * 0.8f);
                    break;
                case EnemyIntent.Retreat:
                    Retreat(toTarget);
                    break;
                case EnemyIntent.Attack:
                    Stop();
                    if (toTarget.sqrMagnitude > 0.001f)
                        transform.rotation = Quaternion.RotateTowards(transform.rotation,
                            Quaternion.LookRotation(toTarget), 720 * Time.deltaTime);
                    if (Vector3.Angle(transform.forward, toTarget) < 8) combat.TryAttack(ranged);
                    break;
            }
            animationView.SetSpeed(agent.velocity.magnitude);
        }
        private void Stop()
        {
            agent.isStopped = true;
            if (agent.hasPath) agent.ResetPath();
            agent.velocity = Vector3.zero;
        }
        private void Navigate(Vector3 destination, float stopDistance)
        {
            agent.isStopped = false;
            agent.stoppingDistance = stopDistance;
            if (Time.time < nextPath) return;
            nextPath = Time.time + 0.2f;
            agent.SetDestination(destination);
        }
        private void Retreat(Vector3 toTarget)
        {
            if (Time.time < nextPath) return;
            nextPath = Time.time + 0.25f;
            // Try a fan of reachable escape points, including sideways near a wall.
            Vector3 away = toTarget.sqrMagnitude > 0.001f ? -toTarget.normalized : -transform.forward;
            float best = toTarget.sqrMagnitude;
            Vector3 destination = transform.position;
            for (int i = -2; i <= 2; i++)
            {
                Vector3 point = transform.position + Quaternion.Euler(0, i * 40, 0) * away * 4;
                if (!NavMesh.SamplePosition(point, out var hit, 1.5f, NavMesh.AllAreas) ||
                    !agent.CalculatePath(hit.position, candidatePath) || candidatePath.status != NavMeshPathStatus.PathComplete) continue;
                float score = (hit.position - target.transform.position).sqrMagnitude;
                if (score > best) { best = score; destination = hit.position; }
            }
            if (destination == transform.position) { Stop(); return; }
            agent.isStopped = false;
            agent.stoppingDistance = 0.2f;
            agent.SetDestination(destination);
        }
    }
}

using System.Collections.Generic;
using Lab12.Domain;
using UnityEngine;

namespace Lab12.Runtime
{
    public static class CombatPhysics
    {
        public const int WorldLayer = 8;
        public const int ActorLayer = 9;
        public const int WorldMask = 1 << WorldLayer;
        public const int CombatMask = WorldMask | (1 << ActorLayer);

        public static bool ClearLine(Vector3 from, Vector3 to) =>
            !Physics.Linecast(from, to, WorldMask, QueryTriggerInteraction.Ignore);
    }

    public sealed class MeleeAttack : IAttackEffect
    {
        private readonly Combatant owner;
        private readonly CharacterDefinition settings;
        public MeleeAttack(Combatant owner, CharacterDefinition settings)
        { this.owner = owner; this.settings = settings; }

        public void Execute()
        {
            if (!owner.IsAlive) return;
            var struck = new HashSet<Combatant>();
            foreach (var collider in Physics.OverlapSphere(owner.AimPoint, settings.meleeReach,
                1 << CombatPhysics.ActorLayer, QueryTriggerInteraction.Ignore))
            {
                var target = collider.GetComponentInParent<Combatant>();
                if (target == null || !target.IsAlive || target.Faction == owner.Faction || !struck.Add(target)) continue;
                Vector3 direction = target.transform.position - owner.transform.position;
                direction.y = 0;
                if (direction.magnitude > settings.meleeReach ||
                    Vector3.Angle(owner.transform.forward, direction) > settings.meleeArc * 0.5f ||
                    !CombatPhysics.ClearLine(owner.AimPoint, target.AimPoint)) continue;
                IDamageReceiver receiver = target;
                receiver.Receive(new Damage(settings.physicalDamage, DamageType.Physical, owner.Faction));
            }
        }
    }

    public sealed class MagicAttack : IAttackEffect
    {
        private readonly Combatant owner;
        private readonly CharacterDefinition settings;
        private readonly ProjectileFactory projectiles;
        public MagicAttack(Combatant owner, CharacterDefinition settings, ProjectileFactory projectiles)
        { this.owner = owner; this.settings = settings; this.projectiles = projectiles; }
        public void Execute()
        {
            if (owner.IsAlive) projectiles.Spawn(owner, settings, owner.transform.forward);
        }
    }
}

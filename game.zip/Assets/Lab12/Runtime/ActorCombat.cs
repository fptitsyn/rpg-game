using Lab12.Domain;
using UnityEngine;

namespace Lab12.Runtime
{
    public sealed class ActorCombat : MonoBehaviour
    {
        private Combatant actor;
        private CharacterDefinition definition;
        private ICharacterAnimation animationView;
        private IAttackEffect melee;
        private IAttackEffect magic;
        private readonly AttackTimeline timeline = new AttackTimeline();
        private float hitUntil;
        private float nextMelee;
        private float nextMagic;
        private bool wasLocked;
        public bool IsLocked => !actor.IsAlive || Time.time < hitUntil || timeline.IsRunning;
        public float MagicRemaining => Mathf.Max(0, nextMagic - Time.time);
        public float MagicCooldown => definition.magicCooldown;

        public void Initialize(Combatant owner, CharacterDefinition settings,
            ICharacterAnimation view, IAttackEffect physical, IAttackEffect magical)
        {
            actor = owner;
            definition = settings;
            animationView = view;
            melee = physical;
            magic = magical;
            actor.Health.Damaged += OnDamaged;
            actor.Health.Died += OnDied;
        }
        public bool TryAttack(bool magical)
        {
            if (IsLocked || Time.time < (magical ? nextMagic : nextMelee)) return false;
            float duration = magical ? definition.magicDuration : definition.meleeDuration;
            float impact = magical ? definition.magicImpact : definition.meleeImpact;
            if (!timeline.TryStart(impact, duration, magical ? magic : melee)) return false;
            if (magical) nextMagic = Time.time + definition.magicCooldown;
            else nextMelee = Time.time + definition.meleeCooldown;
            animationView.PlayAction(magical ? "Magic" : "Melee");
            wasLocked = true;
            return true;
        }
        private void Update()
        {
            if (actor == null || !actor.IsAlive) return;
            timeline.Tick(Time.deltaTime);
            if (wasLocked && !IsLocked) animationView.ResumeLocomotion();
            wasLocked = IsLocked;
        }
        private void OnDamaged(Damage damage)
        {
            timeline.Cancel();
            hitUntil = Time.time + definition.hitDuration;
            wasLocked = true;
            animationView.PlayAction("Hit");
        }
        private void OnDied()
        {
            timeline.Cancel();
            animationView.PlayAction("Death");
            if (actor.Faction == Faction.Enemy) Destroy(gameObject, definition.deathDuration);
        }
        private void OnDisable() => timeline.Cancel();
        private void OnDestroy()
        {
            if (actor == null || actor.Health == null) return;
            actor.Health.Damaged -= OnDamaged;
            actor.Health.Died -= OnDied;
        }
    }
}

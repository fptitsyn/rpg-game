using UnityEngine;

namespace Lab12.Runtime
{
    public sealed class PlayerMotor : MonoBehaviour
    {
        private CharacterController controller;
        private ActorCombat combat;
        private ICharacterAnimation animationView;
        private Vector3 desiredVelocity;
        private float verticalSpeed;
        public void Initialize(CharacterController body, ActorCombat attacks, ICharacterAnimation view)
        { controller = body; combat = attacks; animationView = view; }
        public void SetVelocity(Vector3 velocity) => desiredVelocity = velocity;
        private void LateUpdate()
        {
            if (controller == null || !controller.enabled) return;
            if (controller.isGrounded && verticalSpeed < 0) verticalSpeed = -2;
            verticalSpeed += Physics.gravity.y * Time.deltaTime;
            Vector3 horizontal = combat.IsLocked ? Vector3.zero : desiredVelocity;
            controller.Move((horizontal + Vector3.up * verticalSpeed) * Time.deltaTime);
            Vector3 actual = controller.velocity;
            actual.y = 0;
            animationView.SetSpeed(actual.magnitude);
        }
    }
}

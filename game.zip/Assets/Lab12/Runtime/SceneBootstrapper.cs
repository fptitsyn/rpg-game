using Unity.AI.Navigation;
using UnityEngine;
using UnityEngine.AI;

namespace Lab12.Runtime
{
    public sealed class SceneBootstrapper : MonoBehaviour
    {
        public CharacterDefinition player;
        public CharacterDefinition meleeEnemy;
        public CharacterDefinition rangedEnemy;
        public Material projectileMaterial;
        public NavMeshSurface navigation;
        public Camera gameCamera;
        public Vector3 playerSpawn = new Vector3(0, 0, -12);
        private PlayerInput input;
        private UiFactory ui;
        private CursorLockMode previousLock;
        private bool previousVisible;

        private void Awake()
        {
            previousLock = Cursor.lockState; previousVisible = Cursor.visible;
            if (!Valid(player) || !Valid(meleeEnemy) || !Valid(rangedEnemy) ||
                navigation == null || gameCamera == null || projectileMaterial == null)
            {
                Debug.LogError("Lab12 setup is incomplete. Run Tools > Lab 1-2 > Build playable scene.");
                enabled = false;
                return;
            }
            // Bake before adding actors; only World layer participates in navigation.
            navigation.BuildNavMesh();
            if (!NavMesh.SamplePosition(playerSpawn, out var start, 2, NavMesh.AllAreas))
            { Debug.LogError("Lab12: player spawn is outside NavMesh."); enabled = false; return; }
            input = new PlayerInput();
            ui = new UiFactory();
            var factory = new ActorFactory(new ProjectileFactory(projectileMaterial), ui, gameCamera);
            var orbit = gameCamera.gameObject.AddComponent<OrbitCamera>();
            var hero = factory.CreatePlayer(player, start.position, input, orbit);
            var spawner = new EnemySpawner(factory);
            spawner.Spawn(meleeEnemy, hero, false, Random.Range(2, 4));
            spawner.Spawn(rangedEnemy, hero, true, Random.Range(2, 4));
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
        private static bool Valid(CharacterDefinition settings) => settings != null &&
            settings.visualPrefab != null && settings.controller != null &&
            settings.visualPrefab.GetComponentInChildren<Animator>() != null;
        private void OnDestroy()
        {
            input?.Dispose();
            ui?.Dispose();
            Cursor.lockState = previousLock; Cursor.visible = previousVisible;
        }
    }
}

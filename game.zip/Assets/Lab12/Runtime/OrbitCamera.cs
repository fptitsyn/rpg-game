using UnityEngine;

namespace Lab12.Runtime
{
    [DefaultExecutionOrder(100)]
    public sealed class OrbitCamera : MonoBehaviour
    {
        private Transform target;
        private float pitch = 24;
        public float Yaw { get; private set; }
        [SerializeField] private float sensitivity = 0.12f;
        [SerializeField] private float distance = 5;
        public void Initialize(Transform follow) { target = follow; Yaw = follow.eulerAngles.y; }
        public void Rotate(Vector2 mouseDelta)
        {
            // Mouse delta is already per frame, so it must not be multiplied by deltaTime.
            Yaw += mouseDelta.x * sensitivity;
            pitch = Mathf.Clamp(pitch - mouseDelta.y * sensitivity, -15, 65);
        }
        private void LateUpdate()
        {
            if (target == null) return;
            Vector3 pivot = target.position + Vector3.up * 1.45f;
            Quaternion rotation = Quaternion.Euler(pitch, Yaw, 0);
            Vector3 backwards = rotation * Vector3.back;
            float actualDistance = distance;
            if (Physics.SphereCast(pivot, 0.2f, backwards, out var hit, distance,
                CombatPhysics.WorldMask, QueryTriggerInteraction.Ignore)) actualDistance = Mathf.Max(0.15f, hit.distance - 0.05f);
            transform.SetPositionAndRotation(pivot + backwards * actualDistance, rotation);
        }
    }
}

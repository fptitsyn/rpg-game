using System;
using Lab12.Domain;
using UnityEngine;

namespace Lab12.Runtime
{
    public sealed class MagicProjectile : MonoBehaviour
    {
        private Vector3 velocity;
        private float remaining;
        private Damage damage;
        private const float Radius = 0.14f;
        public void Initialize(Vector3 speed, float lifetime, Damage hit)
        { velocity = speed; remaining = lifetime; damage = hit; }

        private void Update()
        {
            float step = Mathf.Min(Time.deltaTime, remaining);
            if (step <= 0) { Destroy(gameObject); return; }
            Vector3 origin = transform.position;
            // SphereCast does not report an initial overlap; handle it separately.
            foreach (var collider in Physics.OverlapSphere(origin, Radius,
                CombatPhysics.CombatMask, QueryTriggerInteraction.Ignore))
                if (Impact(collider)) return;
            Vector3 displacement = velocity * step;
            var hits = Physics.SphereCastAll(origin, Radius, displacement.normalized,
                displacement.magnitude, CombatPhysics.CombatMask, QueryTriggerInteraction.Ignore);
            Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
            foreach (var hit in hits)
                if (Impact(hit.collider)) return;
            transform.position += displacement;
            remaining -= step;
            if (remaining <= 0) Destroy(gameObject);
        }
        private bool Impact(Collider coll)
        {
            Combatant target = coll.GetComponentInParent<Combatant>();
            if (target)
            {
                if (!target.IsAlive || target.Faction == damage.Source) return false;
                IDamageReceiver receiver = target;
                receiver.Receive(damage);
            }
            Destroy(gameObject);
            enabled = false;
            return true;
        }
    }
}

using System;
using System.Linq;
using Lab12.Runtime;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace Lab12.Editor
{
    public static class LabValidator
    {
        [MenuItem("Tools/Lab 1-2/Validate generated assets")]
        public static void Validate()
        {
            int errors = 0;
            foreach (string name in new[] { "Player", "MeleeEnemy", "RangedEnemy" })
            {
                var definition = AssetDatabase.LoadAssetAtPath<CharacterDefinition>(LabSceneBuilder.Output + "/" + name + ".asset");
                if (definition == null) { Fail(ref errors, name + ": missing definition. Build scene first."); continue; }
                if (definition.visualPrefab == null || definition.controller == null)
                { Fail(ref errors, name + ": visual/controller missing."); continue; }
                var animator = definition.visualPrefab.GetComponentInChildren<Animator>(true);
                if (animator == null) Fail(ref errors, name + ": Animator missing.");
                else if (!definition.legacyMonsterAnimator && (animator.avatar == null || !animator.avatar.isHuman))
                    Fail(ref errors, name + ": Humanoid Avatar missing.");
                foreach (var renderer in definition.visualPrefab.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    if (renderer.sharedMesh == null) Fail(ref errors, name + ": missing mesh on " + renderer.name);
                foreach (var mono in definition.visualPrefab.GetComponentsInChildren<MonoBehaviour>(true))
                    Fail(ref errors, name + ": unexpected script on visual: " + (mono == null ? "Missing Script" : mono.GetType().Name));
                if (definition.meleeImpact < 0 || definition.meleeImpact > definition.meleeDuration ||
                    definition.magicImpact < 0 || definition.magicImpact > definition.magicDuration)
                    Fail(ref errors, name + ": impact outside animation duration.");
                foreach (var clip in definition.controller.animationClips)
                    if (AnimationUtility.GetAnimationEvents(clip).Length > 0)
                        Fail(ref errors, name + ": vendor events remain in " + clip.name);
                if (!definition.legacyMonsterAnimator)
                {
                    var generated = definition.controller as AnimatorController;
                    if (generated == null || !generated.parameters.Any(p => p.name == "ActionSpeed" && p.type == AnimatorControllerParameterType.Float))
                        Fail(ref errors, name + ": ActionSpeed parameter missing.");
                }
                if (definition.legacyMonsterAnimator && animator != null)
                {
                    // Runtime parameters are validated from the controller asset, not an inactive Animator.
                    var controller = definition.controller;
                    while (controller is AnimatorOverrideController overrides) controller = overrides.runtimeAnimatorController;
                    var parameters = ((AnimatorController)controller).parameters;
                    foreach (string trigger in new[] { "Attack", "TakeDamage", "Death" })
                        if (!parameters.Any(p => p.name == trigger && p.type == AnimatorControllerParameterType.Trigger))
                            Fail(ref errors, name + ": expected trigger " + trigger + ". Adjust CharacterAnimation adapter to the source controller.");
                    if (!parameters.Any(p => p.name == "Walking" && p.type == AnimatorControllerParameterType.Bool))
                        Fail(ref errors, name + ": expected Walking bool.");
                }
            }
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(LabSceneBuilder.ScenePath) == null)
                Fail(ref errors, "Playable scene missing.");
            if (errors > 0) throw new InvalidOperationException("Lab12 validation failed: " + errors + " error(s).");
            Debug.Log("Lab12 asset validation passed. Next: Test Runner (EditMode + PlayMode) and manual gameplay checks.");
        }
        private static void Fail(ref int errors, string message) { errors++; Debug.LogError(message); }
    }
}

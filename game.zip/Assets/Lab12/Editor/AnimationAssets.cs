using System;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Lab12.Editor
{
    public static class AnimationAssets
    {
        private static readonly string[] States = { "Idle", "Walk", "Run", "Melee", "Magic", "Hit", "Death" };
        private static readonly string[] Sources = { "Idle", "WalkForward", "Run", "Attack1", "RangeAttack1", "LightHit", "Death" };
        public static RuntimeAnimatorController Create()
        {
            var clips = new AnimationClip[States.Length];
            for (int i = 0; i < States.Length; i++) clips[i] = Copy(States[i], Sources[i], i < 3);
            string path = LabSceneBuilder.Output + "/Character.controller";
            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            if (controller != null) return controller;
            controller = AnimatorController.CreateAnimatorControllerAtPath(path);
            controller.AddParameter("Speed", AnimatorControllerParameterType.Float);
            controller.AddParameter(new AnimatorControllerParameter { name = "ActionSpeed", type = AnimatorControllerParameterType.Float, defaultFloat = 1 });
            var machine = controller.layers[0].stateMachine;
            var locomotion = machine.AddState("Locomotion", new Vector3(250, 60));
            var blend = new BlendTree { name = "Idle - Walk - Run", blendType = BlendTreeType.Simple1D,
                blendParameter = "Speed", useAutomaticThresholds = false };
            AssetDatabase.AddObjectToAsset(blend, controller);
            blend.AddChild(clips[0], 0); blend.AddChild(clips[1], 3.5f); blend.AddChild(clips[2], 6);
            locomotion.motion = blend; locomotion.writeDefaultValues = false;
            machine.defaultState = locomotion;
            for (int i = 3; i < States.Length; i++)
            {
                var state = machine.AddState(States[i], new Vector3(250, 60 + (i - 2) * 70));
                state.motion = clips[i]; state.writeDefaultValues = false;
                state.speedParameter = "ActionSpeed"; state.speedParameterActive = true;
            }
            // No Any State and no queued triggers. Combat explicitly owns interruption/return.
            EditorUtility.SetDirty(controller);
            return controller;
        }
        public static float Length(string state) =>
            AssetDatabase.LoadAssetAtPath<AnimationClip>(LabSceneBuilder.Output + "/Clips/" + state + ".anim").length;

        private static AnimationClip Copy(string state, string sourceName, bool loop)
        {
            string targetPath = LabSceneBuilder.Output + "/Clips/" + state + ".anim";
            var saved = AssetDatabase.LoadAssetAtPath<AnimationClip>(targetPath);
            if (saved != null) return saved;
            string sourcePath = LabSceneBuilder.Pack + "/Animations/Sorceress@" + sourceName + ".FBX";
            var source = AssetDatabase.LoadAllAssetsAtPath(sourcePath).OfType<AnimationClip>()
                .FirstOrDefault(c => !c.name.StartsWith("__preview__", StringComparison.Ordinal));
            if (source == null) throw new InvalidOperationException("Missing animation: " + sourcePath);
            var clip = Object.Instantiate(source);
            clip.name = state;
            // Vendor events call WarriorController, which this scene does not use.
            AnimationUtility.SetAnimationEvents(clip, Array.Empty<AnimationEvent>());
            var settings = AnimationUtility.GetAnimationClipSettings(clip);
            settings.loopTime = loop; settings.loopBlend = loop;
            settings.keepOriginalOrientation = true;
            settings.keepOriginalPositionXZ = true;
            settings.keepOriginalPositionY = true;
            settings.loopBlendOrientation = true;
            settings.loopBlendPositionY = true;
            settings.loopBlendPositionXZ = true;
            AnimationUtility.SetAnimationClipSettings(clip, settings);
            AssetDatabase.CreateAsset(clip, targetPath);
            return clip;
        }
    }
}

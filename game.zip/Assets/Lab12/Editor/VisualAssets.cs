using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Lab12.Editor
{
    public static class VisualAssets
    {
        public static GameObject CreateSorceress(string name, Color color, bool sword)
        {
            string path = LabSceneBuilder.Output + "/" + name + ".prefab";
            var saved = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (saved != null) return saved;
            var source = AssetDatabase.LoadAssetAtPath<GameObject>(LabSceneBuilder.Pack + "/Characters/Sorceress.FBX");
            if (source == null) throw new InvalidOperationException("Sorceress model is missing.");
            var root = new GameObject(name);
            try
            {
                var model = Object.Instantiate(source, root.transform);
                model.name = "Sorceress";
                // FBX includes alternative meshes on the same rig. Show only Sorceress.
                foreach (var renderer in model.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    if (renderer.name.Contains("Karate") || renderer.name.Contains("Ninja")) renderer.gameObject.SetActive(false);
                ConvertMaterials(model, name, color);
                var skin = AssetDatabase.LoadAssetAtPath<Texture2D>(LabSceneBuilder.Pack + "/Textures/Sorceress.psd");
                foreach (var renderer in model.GetComponentsInChildren<Renderer>(true))
                    foreach (var material in renderer.sharedMaterials)
                        if (material != null && skin != null)
                        { material.SetTexture("_BaseMap", skin); EditorUtility.SetDirty(material); }
                Normalize(model);
                var animator = model.GetComponentInChildren<Animator>();
                if (animator == null || animator.avatar == null || !animator.avatar.isHuman)
                    throw new InvalidOperationException("Sorceress must import with a valid Humanoid Avatar.");
                animator.runtimeAnimatorController = null; animator.applyRootMotion = false;
                if (sword) AttachSword(model);
                return PrefabUtility.SaveAsPrefabAsset(root, path);
            }
            finally { Object.DestroyImmediate(root); }
        }
        public static void ConvertMaterials(GameObject model, string prefix, Color tint)
        {
            int index = 0;
            foreach (var renderer in model.GetComponentsInChildren<Renderer>(true))
            {
                var materials = renderer.sharedMaterials;
                if (materials.Length == 0) materials = new Material[1];
                for (int i = 0; i < materials.Length; i++)
                {
                    var source = materials[i];
                    var result = LabSceneBuilder.Material(prefix + "_Material" + index++, tint);
                    if (source != null)
                    {
                        Texture texture = source.HasProperty("_BaseMap") ? source.GetTexture("_BaseMap") :
                            source.HasProperty("_MainTex") ? source.GetTexture("_MainTex") : null;
                        if (texture != null) result.SetTexture("_BaseMap", texture);
                        EditorUtility.SetDirty(result);
                    }
                    materials[i] = result;
                }
                renderer.sharedMaterials = materials;
            }
        }
        public static void Normalize(GameObject model)
        {
            var renderers = model.GetComponentsInChildren<Renderer>().Where(r => r.enabled).ToArray();
            if (renderers.Length == 0) throw new InvalidOperationException("Visual has no renderer.");
            Bounds bounds = renderers[0].bounds;
            foreach (var renderer in renderers) bounds.Encapsulate(renderer.bounds);
            if (bounds.size.y < 0.01f) throw new InvalidOperationException("Visual mesh is missing or has zero height.");
            float scale = 1.8f / bounds.size.y;
            model.transform.localScale *= scale;
            // Scale around model origin, then put its feet on the actor origin.
            model.transform.localPosition = new Vector3(-bounds.center.x, -bounds.min.y, -bounds.center.z) * scale;
        }
        private static void AttachSword(GameObject model)
        {
            var hand = model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t => t.name == "B_R_Hand");
            if (hand == null) throw new InvalidOperationException("Cannot locate Sorceress right hand.");
            var weapon = new GameObject("Sword");
            weapon.transform.SetParent(hand, false);
            weapon.transform.localRotation = Quaternion.Euler(0, 0, 90);
            // FBX bone units can differ; keep the weapon dimensions in metres.
            Vector3 parentScale = hand.lossyScale;
            weapon.transform.localScale = new Vector3(1 / Mathf.Abs(parentScale.x), 1 / Mathf.Abs(parentScale.y), 1 / Mathf.Abs(parentScale.z));
            Part("Blade", weapon.transform, new Vector3(0, 0.52f, 0), new Vector3(0.055f, 0.85f, 0.025f),
                LabSceneBuilder.Material("SwordSteel", new Color(0.75f, 0.85f, 0.95f)));
            Part("Guard", weapon.transform, new Vector3(0, 0.08f, 0), new Vector3(0.22f, 0.05f, 0.055f),
                LabSceneBuilder.Material("SwordGold", new Color(0.55f, 0.38f, 0.1f)));
            Part("Handle", weapon.transform, new Vector3(0, -0.04f, 0), new Vector3(0.05f, 0.18f, 0.05f),
                LabSceneBuilder.Material("SwordGrip", new Color(0.15f, 0.08f, 0.04f)));
        }
        private static void Part(string name, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            var part = GameObject.CreatePrimitive(PrimitiveType.Cube);
            part.name = name; part.transform.SetParent(parent, false);
            part.transform.localPosition = position; part.transform.localScale = scale;
            part.GetComponent<Renderer>().sharedMaterial = material;
            Object.DestroyImmediate(part.GetComponent<Collider>());
        }
    }
}

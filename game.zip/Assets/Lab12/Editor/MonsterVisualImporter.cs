using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Lab12.Runtime;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Lab12.Editor
{
    public static class MonsterVisualImporter
    {
        [MenuItem("Tools/Lab 1-2/Import original monster visuals")]
        public static void Import()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Stop Play mode first.");
            ImportOne("Assets/Prefabs/Melee.prefab", "MeleeEnemy");
            ImportOne("Assets/Prefabs/Range.prefab", "RangedEnemy");
            AssetDatabase.SaveAssets();
        }
        private static void ImportOne(string sourcePath, string definitionName)
        {
            var definition = AssetDatabase.LoadAssetAtPath<CharacterDefinition>(LabSceneBuilder.Output + "/" + definitionName + ".asset");
            if (definition == null) { Debug.LogError("Build the Lab12 scene first."); return; }
            var source = AssetDatabase.LoadAssetAtPath<GameObject>(sourcePath);
            if (source == null) { Debug.LogWarning("Restore Resources with its .meta files before importing " + sourcePath); return; }
            GameObject copy = null;
            try
            {
                copy = Object.Instantiate(source);
                copy.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                var animator = copy.GetComponentInChildren<Animator>(true);
                var renderers = copy.GetComponentsInChildren<SkinnedMeshRenderer>(true);
                if (animator == null || animator.runtimeAnimatorController == null || renderers.Length == 0 || renderers.Any(r => r.sharedMesh == null))
                    throw new InvalidOperationException("Missing controller or mesh. Restore the original Resources folder, including .meta files.");
                var originalController = animator.runtimeAnimatorController;
                // Copy only visual components; no old damage/AI/vendor MonoBehaviours survive.
                foreach (var t in copy.GetComponentsInChildren<Transform>(true))
                    GameObjectUtility.RemoveMonoBehavioursWithMissingScript(t.gameObject);
                var unwanted = copy.GetComponentsInChildren<Component>(true).Where(c =>
                    !(c is Transform) && !(c is Animator) && !(c is Renderer) && !(c is MeshFilter) && !(c is LODGroup)).ToList();
                // Dependents first, then required components such as NavMeshAgent.
                foreach (var c in unwanted.OrderByDescending(c => c is MonoBehaviour)) Object.DestroyImmediate(c);
                var wrapper = new GameObject(definitionName + "Visual");
                copy.transform.SetParent(wrapper.transform, false);
                var child = copy;
                copy = wrapper; // Finally now owns the entire clone.
                VisualAssets.ConvertMaterials(child, definitionName + "Original", Color.white);
                VisualAssets.Normalize(child);
                animator.applyRootMotion = false;
                var cleanController = CleanEvents(originalController, definitionName);
                animator.runtimeAnimatorController = cleanController;
                string path = LabSceneBuilder.Output + "/" + definitionName + "Original.prefab";
                var prefab = PrefabUtility.SaveAsPrefabAsset(wrapper, path);
                definition.visualPrefab = prefab;
                definition.controller = cleanController;
                definition.legacyMonsterAnimator = true;
                definition.visualScale = 1;
                EditorUtility.SetDirty(definition);
                Debug.Log("Imported " + sourcePath + ". Check attack/hit/death durations in " + definitionName + " settings against the original clips.");
            }
            catch (Exception error) { Debug.LogError(sourcePath + ": " + error.Message); }
            finally { if (copy != null) Object.DestroyImmediate(copy); }
        }
        private static RuntimeAnimatorController CleanEvents(RuntimeAnimatorController original, string prefix)
        {
            string path = LabSceneBuilder.Output + "/" + prefix + "Clean.overrideController";
            var saved = AssetDatabase.LoadAssetAtPath<AnimatorOverrideController>(path);
            if (saved != null) return saved;
            var controller = new AnimatorOverrideController(original);
            var pairs = new List<KeyValuePair<AnimationClip, AnimationClip>>();
            controller.GetOverrides(pairs);
            for (int i = 0; i < pairs.Count; i++)
            {
                var source = pairs[i].Value != null ? pairs[i].Value : pairs[i].Key;
                string clipPath = LabSceneBuilder.Output + "/Clips/" + prefix + "_" + i + ".anim";
                var clean = AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);
                if (clean == null)
                {
                    clean = Object.Instantiate(source);
                    clean.name = prefix + "_" + source.name;
                    AnimationUtility.SetAnimationEvents(clean, Array.Empty<AnimationEvent>());
                    AssetDatabase.CreateAsset(clean, clipPath);
                }
                pairs[i] = new KeyValuePair<AnimationClip, AnimationClip>(pairs[i].Key, clean);
            }
            controller.ApplyOverrides(pairs);
            AssetDatabase.CreateAsset(controller, path);
            return controller;
        }
    }
}

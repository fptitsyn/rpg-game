using System;
using System.IO;
using System.Linq;
using Lab12.Runtime;
using Unity.AI.Navigation;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace Lab12.Editor
{
    public static class LabSceneBuilder
    {
        public const string Output = "Assets/Lab12/Generated";
        public const string ScenePath = Output + "/Lab12.unity";
        public const string Pack = "Assets/ExplosiveLLC/Sorceress Warrior Mecanim Animation Pack";

        [MenuItem("Tools/Lab 1-2/Build playable scene")]
        public static void Build()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Stop Play mode first.");
            if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            Directory.CreateDirectory(Output);
            Directory.CreateDirectory(Output + "/Clips");
            AssetDatabase.Refresh();
            ConfigureLayers();
            var animation = AnimationAssets.Create();
            var playerVisual = VisualAssets.CreateSorceress("HeroVisual", new Color(0.85f, 0.91f, 1), true);
            var meleeVisual = VisualAssets.CreateSorceress("MeleeVisual", new Color(1, 0.45f, 0.35f), true);
            var rangedVisual = VisualAssets.CreateSorceress("RangedVisual", new Color(0.6f, 0.4f, 1), false);
            var hero = Definition("Player", playerVisual, animation, 120, 3.5f, 6, 25, 35);
            var melee = Definition("MeleeEnemy", meleeVisual, animation, 70, 2.8f, 4, 12, 0);
            var ranged = Definition("RangedEnemy", rangedVisual, animation, 55, 2.6f, 4, 0, 15);
            ranged.projectileColor = new Color(1, 0.25f, 0.7f);
            EditorUtility.SetDirty(ranged);

            // Rebuild only our scene. Original SampleScene and vendor assets are retained.
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var world = new GameObject("World - 50 x 50 metres");
            var grass = GroundMaterial();
            var stone = Material("Stone", new Color(0.35f, 0.39f, 0.42f));
            var wall = Material("Boundary", new Color(0.18f, 0.25f, 0.22f));
            Block("Ground", world.transform, new Vector3(0, -0.25f, 0), new Vector3(50, 0.5f, 50), grass);
            Block("North fence", world.transform, new Vector3(0, 1.25f, 25), new Vector3(51, 2.5f, 0.5f), wall);
            Block("South fence", world.transform, new Vector3(0, 1.25f, -25), new Vector3(51, 2.5f, 0.5f), wall);
            Block("East fence", world.transform, new Vector3(25, 1.25f, 0), new Vector3(0.5f, 2.5f, 50), wall);
            Block("West fence", world.transform, new Vector3(-25, 1.25f, 0), new Vector3(0.5f, 2.5f, 50), wall);
            var positions = new[] { new Vector3(-8, 1.5f, -4), new Vector3(7, 1, 3), new Vector3(-12, 1, 11),
                new Vector3(12, 1.5f, -11), new Vector3(1, 1, 12), new Vector3(-17, 1, -14), new Vector3(16, 1, 15) };
            for (int i = 0; i < positions.Length; i++)
            {
                var ruin = Block("Ruin " + (i + 1), world.transform, positions[i], new Vector3(3, positions[i].y * 2, 2), stone);
                ruin.transform.rotation = Quaternion.Euler(0, i * 23, 0);
            }
            var surface = world.AddComponent<NavMeshSurface>();
            surface.collectObjects = CollectObjects.Children;
            surface.useGeometry = NavMeshCollectGeometry.PhysicsColliders;
            surface.layerMask = CombatPhysics.WorldMask;
            var light = new GameObject("Daylight").AddComponent<Light>();
            light.type = LightType.Directional; light.intensity = 1.5f; light.shadows = LightShadows.Soft;
            light.transform.rotation = Quaternion.Euler(50, -35, 0);
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.65f, 0.7f, 0.78f);
            var camera = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener)).GetComponent<Camera>();
            camera.tag = "MainCamera";
            camera.nearClipPlane = 0.05f; camera.farClipPlane = 150; camera.fieldOfView = 60;
            camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(0.43f, 0.63f, 0.8f);
            camera.transform.SetPositionAndRotation(new Vector3(0, 4, -17), Quaternion.Euler(24, 0, 0));
            var bootstrap = new GameObject("Scene Bootstrapper").AddComponent<SceneBootstrapper>();
            bootstrap.player = hero; bootstrap.meleeEnemy = melee; bootstrap.rangedEnemy = ranged;
            bootstrap.gameCamera = camera; bootstrap.navigation = surface;
            bootstrap.projectileMaterial = Material("Magic", Color.white);
            AssetDatabase.SaveAssets();
            EditorSceneManager.SaveScene(scene, ScenePath);
            // Keep other entries, with the new playable scene first for Restart/build.
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) }
                .Concat(EditorBuildSettings.scenes.Where(s => s.path != ScenePath)).ToArray();
            Selection.activeGameObject = bootstrap.gameObject;
            Debug.Log("Lab 1-2 ready: press Play. Missing original monster art can be restored later with Import original monster visuals.");
        }

        private static CharacterDefinition Definition(string name, GameObject visual,
            RuntimeAnimatorController controller, float health, float walk, float run, float physical, float magical)
        {
            string path = Output + "/" + name + ".asset";
            var existing = AssetDatabase.LoadAssetAtPath<CharacterDefinition>(path);
            if (existing != null) return existing; // Preserve Inspector tuning on repeated builds.
            var value = ScriptableObject.CreateInstance<CharacterDefinition>();
            value.visualPrefab = visual; value.controller = controller;
            value.health = health; value.walkSpeed = walk; value.runSpeed = run;
            value.physicalDamage = physical; value.magicalDamage = magical;
            value.meleeDuration = AnimationAssets.Length("Melee");
            value.magicDuration = AnimationAssets.Length("Magic");
            value.meleeImpact = value.meleeDuration * 0.38f;
            value.magicImpact = value.magicDuration * 0.35f;
            value.meleeCooldown = value.meleeDuration + 0.25f;
            value.magicCooldown = Mathf.Max(2.2f, value.magicDuration + 0.25f);
            value.hitDuration = 0.35f;
            value.deathDuration = AnimationAssets.Length("Death") + 0.3f;
            AssetDatabase.CreateAsset(value, path);
            return value;
        }
        public static Material Material(string name, Color color)
        {
            string path = Output + "/" + name + ".mat";
            var result = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (result != null) return result;
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) throw new InvalidOperationException("URP/Lit missing; wait for package import.");
            result = new Material(shader) { name = name };
            result.SetColor("_BaseColor", color);
            result.SetFloat("_Smoothness", 0.2f);
            AssetDatabase.CreateAsset(result, path);
            return result;
        }
        private static Material GroundMaterial()
        {
            var result = Material("Ground", Color.white);
            if (result.GetTexture("_BaseMap") != null) return result;
            var texture = new Texture2D(64, 64) { name = "Grass", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
            var random = new System.Random(12);
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++)
                texture.SetPixel(x, y, Color.Lerp(new Color(0.17f, 0.25f, 0.1f), new Color(0.32f, 0.43f, 0.19f), (float)random.NextDouble()));
            texture.Apply();
            File.WriteAllBytes(Output + "/Grass.png", texture.EncodeToPNG());
            Object.DestroyImmediate(texture);
            AssetDatabase.ImportAsset(Output + "/Grass.png");
            result.SetTexture("_BaseMap", AssetDatabase.LoadAssetAtPath<Texture2D>(Output + "/Grass.png"));
            result.SetTextureScale("_BaseMap", new Vector2(24, 24));
            EditorUtility.SetDirty(result);
            return result;
        }
        private static GameObject Block(string name, Transform parent, Vector3 position, Vector3 size, Material material)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name; go.layer = CombatPhysics.WorldLayer; go.isStatic = true;
            go.transform.SetParent(parent, false); go.transform.position = position; go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = material;
            return go;
        }
        private static void ConfigureLayers()
        {
            var asset = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
            var layers = asset.FindProperty("layers");
            SetLayer(layers, CombatPhysics.WorldLayer, "LabWorld");
            SetLayer(layers, CombatPhysics.ActorLayer, "LabActors");
            asset.ApplyModifiedPropertiesWithoutUndo();
        }
        private static void SetLayer(SerializedProperty layers, int index, string name)
        {
            var layer = layers.GetArrayElementAtIndex(index);
            if (!string.IsNullOrEmpty(layer.stringValue) && layer.stringValue != name)
                throw new InvalidOperationException("Layer " + index + " is occupied by " + layer.stringValue + ". Change CombatPhysics layer constants first.");
            layer.stringValue = name;
        }
    }
}

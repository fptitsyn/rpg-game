using System;

namespace Lab12.Domain
{
    public interface IAttackEffect { void Execute(); }

    // One hit/release per attack, including frames longer than the whole animation.
    public sealed class AttackTimeline
    {
        private float elapsed;
        private float impactTime;
        private float duration;
        private bool committed;
        private IAttackEffect effect;
        public bool IsRunning { get; private set; }

        public bool TryStart(float impact, float length, IAttackEffect attackEffect)
        {
            if (IsRunning) return false;
            if (float.IsNaN(impact) || float.IsInfinity(impact) || impact < 0 ||
                float.IsNaN(length) || float.IsInfinity(length) || length <= 0 || impact > length)
                throw new ArgumentOutOfRangeException(nameof(impact));
            effect = attackEffect ?? throw new ArgumentNullException(nameof(attackEffect));
            elapsed = 0;
            impactTime = impact;
            duration = length;
            committed = false;
            IsRunning = true;
            return true;
        }

        public void Tick(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0)
                throw new ArgumentOutOfRangeException(nameof(deltaTime));
            if (!IsRunning) return;
            elapsed += deltaTime;
            if (!committed && elapsed >= impactTime)
            {
                committed = true;
                effect.Execute();
            }
            if (elapsed >= duration) Cancel();
        }

        public void Cancel()
        {
            IsRunning = false;
            effect = null;
        }
    }
}

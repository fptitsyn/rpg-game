using System.Collections.Generic;
using Lab12.Domain;
using Lab12.Runtime;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Lab12.Tests
{
    public sealed class CombatPhysicsTests
    {
        private readonly List<Object> created = new List<Object>();
        private CharacterDefinition definition;

        [SetUp]
        public void SetUp()
        {
            definition = ScriptableObject.CreateInstance<CharacterDefinition>();
            definition.meleeReach = 2;
            definition.physicalDamage = 20;
            created.Add(definition);
        }
        [TearDown]
        public void TearDown()
        {
            foreach (var item in created) Object.DestroyImmediate(item);
            created.Clear();
        }
        private Combatant Actor(Faction faction, Vector3 position)
        {
            var go = new GameObject("Test actor");
            created.Add(go);
            go.transform.position = position;
            go.layer = CombatPhysics.ActorLayer;
            var actor = go.AddComponent<Combatant>();
            actor.Initialize(100, faction);
            var collider = go.AddComponent<CapsuleCollider>();
            collider.height = 1.8f;
            collider.center = Vector3.up * 0.9f;
            collider.radius = 0.3f;
            return actor;
        }
        [Test]
        public void MeleeDeduplicatesMultipleCollidersOnSameVictim()
        {
            var attacker = Actor(Faction.Player, Vector3.zero);
            var victim = Actor(Faction.Enemy, Vector3.forward * 1.5f);
            victim.gameObject.AddComponent<BoxCollider>().center = Vector3.up;
            Physics.SyncTransforms();
            new MeleeAttack(attacker, definition).Execute();
            Assert.That(victim.Health.Current, Is.EqualTo(80));
        }
        [Test]
        public void MeleeDoesNotHitBehindOrFriendlyActors()
        {
            var attacker = Actor(Faction.Player, Vector3.zero);
            var behind = Actor(Faction.Enemy, Vector3.back);
            var friend = Actor(Faction.Player, Vector3.forward);
            Physics.SyncTransforms();
            new MeleeAttack(attacker, definition).Execute();
            Assert.That(behind.Health.Current, Is.EqualTo(100));
            Assert.That(friend.Health.Current, Is.EqualTo(100));
        }
        [Test]
        public void WallBlocksMeleeDamage()
        {
            var attacker = Actor(Faction.Player, Vector3.zero);
            var victim = Actor(Faction.Enemy, Vector3.forward * 1.8f);
            var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            created.Add(wall);
            wall.layer = CombatPhysics.WorldLayer;
            wall.transform.position = new Vector3(0, 1, 0.9f);
            wall.transform.localScale = new Vector3(3, 2, 0.2f);
            Physics.SyncTransforms();
            new MeleeAttack(attacker, definition).Execute();
            Assert.That(victim.Health.Current, Is.EqualTo(100));
        }
        [Test]
        public void CombatantRejectsFriendlyDamage()
        {
            var actor = Actor(Faction.Player, Vector3.zero);
            actor.Receive(new Damage(30, DamageType.Magical, Faction.Player));
            Assert.That(actor.Health.Current, Is.EqualTo(100));
        }
    }
}

using System;
using Lab12.Domain;
using NUnit.Framework;

namespace Lab12.Tests
{
    public sealed class DomainTests
    {
        private sealed class CountingEffect : IAttackEffect
        {
            public int Count;
            public void Execute() => Count++;
        }

        [Test]
        public void NewHealthStartsFull()
        {
            var health = new Health(100);
            Assert.That(health.Current, Is.EqualTo(100));
            Assert.That(health.IsAlive, Is.True);
        }

        [TestCase(0)]
        [TestCase(-1)]
        [TestCase(float.NaN)]
        [TestCase(float.PositiveInfinity)]
        public void InvalidMaximumRejected(float value) =>
            Assert.Throws<ArgumentOutOfRangeException>(() => new Health(value));

        [Test]
        public void NonFatalHitUpdatesUiAndReaction()
        {
            var health = new Health(100);
            float displayed = 0;
            DamageType receivedType = DamageType.Physical;
            health.Changed += (hp, max) => displayed = hp;
            health.Damaged += hit => receivedType = hit.Type;
            health.Receive(new Damage(25, DamageType.Magical, Faction.Enemy));
            Assert.That(displayed, Is.EqualTo(75));
            Assert.That(receivedType, Is.EqualTo(DamageType.Magical));
        }

        [Test]
        public void DeathOccursOnceAndDoesNotScheduleHitReaction()
        {
            var health = new Health(20);
            int deaths = 0, reactions = 0, changes = 0;
            health.Died += () => deaths++;
            health.Damaged += _ => reactions++;
            health.Changed += (_, __) => changes++;
            health.Receive(new Damage(25, DamageType.Physical, Faction.Enemy));
            health.Receive(new Damage(25, DamageType.Magical, Faction.Enemy));
            Assert.That(health.Current, Is.Zero);
            Assert.That(health.IsAlive, Is.False);
            Assert.That(deaths, Is.EqualTo(1));
            Assert.That(reactions, Is.Zero);
            Assert.That(changes, Is.EqualTo(1));
        }

        [Test]
        public void ZeroDamageDoesNotStun()
        {
            var health = new Health(20);
            int reactions = 0;
            health.Damaged += _ => reactions++;
            health.Receive(new Damage(0, DamageType.Physical, Faction.Enemy));
            Assert.That(reactions, Is.Zero);
            Assert.That(health.Current, Is.EqualTo(20));
        }

        [TestCase(-1)]
        [TestCase(float.NaN)]
        [TestCase(float.PositiveInfinity)]
        public void InvalidDamageRejected(float value) =>
            Assert.Throws<ArgumentOutOfRangeException>(() => new Damage(value, DamageType.Physical, Faction.Player));

        [Test]
        public void AttackHitsOnlyAtImpactAndOnlyOnce()
        {
            var attack = new AttackTimeline();
            var effect = new CountingEffect();
            attack.TryStart(0.5f, 1, effect);
            attack.Tick(0.25f);
            Assert.That(effect.Count, Is.Zero);
            attack.Tick(0.25f);
            attack.Tick(0.25f);
            Assert.That(effect.Count, Is.EqualTo(1));
            Assert.That(attack.IsRunning, Is.True);
            attack.Tick(0.25f);
            Assert.That(attack.IsRunning, Is.False);
        }

        [Test]
        public void LongFrameDoesNotSkipOrDuplicateHit()
        {
            var attack = new AttackTimeline();
            var effect = new CountingEffect();
            attack.TryStart(0.5f, 1, effect);
            attack.Tick(2);
            attack.Tick(2);
            Assert.That(effect.Count, Is.EqualTo(1));
            Assert.That(attack.IsRunning, Is.False);
        }

        [Test]
        public void StunBeforeImpactCancelsHit()
        {
            var attack = new AttackTimeline();
            var effect = new CountingEffect();
            attack.TryStart(0.5f, 1, effect);
            attack.Tick(0.25f);
            attack.Cancel();
            attack.Tick(1);
            Assert.That(effect.Count, Is.Zero);
        }

        [Test]
        public void CannotQueueAnotherAttackWhileAttacking()
        {
            var attack = new AttackTimeline();
            var first = new CountingEffect();
            var second = new CountingEffect();
            Assert.That(attack.TryStart(0.2f, 1, first), Is.True);
            Assert.That(attack.TryStart(0.2f, 1, second), Is.False);
            attack.Tick(1);
            Assert.That(first.Count, Is.EqualTo(1));
            Assert.That(second.Count, Is.Zero);
        }

        [Test]
        public void NewAttackAfterCancellationHasOwnImpact()
        {
            var attack = new AttackTimeline();
            var effect = new CountingEffect();
            attack.TryStart(0.2f, 1, effect);
            attack.Cancel();
            Assert.That(attack.TryStart(0.2f, 1, effect), Is.True);
            attack.Tick(1);
            Assert.That(effect.Count, Is.EqualTo(1));
        }

        [TestCase(1.1f, 1)]
        [TestCase(-1, 1)]
        [TestCase(0, 0)]
        public void InvalidAttackTimingRejected(float impact, float duration) =>
            Assert.Throws<ArgumentOutOfRangeException>(() => new AttackTimeline().TryStart(impact, duration, new CountingEffect()));

        [TestCase(10.01f, true, false, true, EnemyIntent.Idle)]
        [TestCase(10, true, false, true, EnemyIntent.Approach)]
        [TestCase(2, true, false, true, EnemyIntent.Attack)]
        [TestCase(2, false, false, true, EnemyIntent.Idle)]
        [TestCase(2, true, false, false, EnemyIntent.Approach)]
        [TestCase(4.99f, true, true, true, EnemyIntent.Retreat)]
        [TestCase(5, true, true, true, EnemyIntent.Attack)]
        [TestCase(10, true, true, true, EnemyIntent.Attack)]
        [TestCase(10.01f, true, true, true, EnemyIntent.Idle)]
        [TestCase(7, true, true, false, EnemyIntent.Approach)]
        public void EnemyPolicyMatchesSpecification(float distance, bool alive, bool ranged, bool visible, EnemyIntent expected) =>
            Assert.That(EnemyDecision.Evaluate(distance, alive, ranged, visible), Is.EqualTo(expected));
    }
}

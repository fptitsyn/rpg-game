using System.Collections;
using System.Collections.Generic;
using Lab12.Domain;
using Lab12.Runtime;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Lab12.Tests
{
    public sealed class ProjectileTests
    {
        private readonly List<GameObject> created = new List<GameObject>();
        private Combatant Target(Vector3 position)
        {
            var go = new GameObject("Projectile target");
            created.Add(go);
            go.layer = CombatPhysics.ActorLayer;
            go.transform.position = position;
            go.AddComponent<SphereCollider>().radius = 0.4f;
            var actor = go.AddComponent<Combatant>();
            actor.Initialize(100, Faction.Enemy);
            return actor;
        }
        private MagicProjectile Projectile()
        {
            var go = new GameObject("Test projectile");
            created.Add(go);
            var projectile = go.AddComponent<MagicProjectile>();
            projectile.Initialize(Vector3.forward * 1000, 1, new Damage(25, DamageType.Magical, Faction.Player));
            return projectile;
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (var go in created) if (go != null) Object.Destroy(go);
            created.Clear();
            yield return null;
        }
        [UnityTest]
        public IEnumerator FastProjectileHitsOnceWithoutTunnelling()
        {
            var target = Target(Vector3.forward * 2);
            var projectile = Projectile();
            Physics.SyncTransforms();
            yield return new WaitForSeconds(0.1f);
            Assert.That(target.Health.Current, Is.EqualTo(75));
            Assert.That(projectile == null, Is.True);
        }
        [UnityTest]
        public IEnumerator WallStopsProjectileBeforeTarget()
        {
            var target = Target(Vector3.forward * 3);
            var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            created.Add(wall);
            wall.layer = CombatPhysics.WorldLayer;
            wall.transform.position = Vector3.forward * 1.5f;
            wall.transform.localScale = new Vector3(3, 3, 0.1f);
            var projectile = Projectile();
            Physics.SyncTransforms();
            yield return new WaitForSeconds(0.1f);
            Assert.That(target.Health.Current, Is.EqualTo(100));
            Assert.That(projectile == null, Is.True);
        }
        [UnityTest]
        public IEnumerator InitialOverlapIsDetected()
        {
            var target = Target(Vector3.zero);
            Projectile();
            Physics.SyncTransforms();
            yield return new WaitForSeconds(0.1f);
            Assert.That(target.Health.Current, Is.EqualTo(75));
        }
    }
}
